# -*- coding: utf-8 -*-
"""
Created on Thu Apr 23 10:09:35 2020

@author: yangy
"""

import matplotlib.pyplot as plt
import numpy as np
F0 = 1

dt = 0.1
nTraj = 500
nStep = 100
sigma = 0.3
beta = 0.5
np.random.seed(1)
for _ in range(nTraj):
    
    x = [F0]
    
    for i in range(nStep):
        
        prevX = x[-1]
        newX = prevX + sigma * (beta * prevX + (1 - beta) * F0) * np.random.randn()
        #newX = prevX + sigma * (beta * prevX) * np.random.randn()
        
        x.append(newX)
        
    plt.figure(1)
    plt.plot(x)
    plt.title('F0 = 1, beta = 0.5')


F0 = 1
beta = -0.5
np.random.seed(1)
for _ in range(nTraj):
    
    x = [F0]
    
    for i in range(nStep):
        
        prevX = x[-1]
        newX = prevX + sigma * (beta * prevX + (1 - beta) * F0) * np.random.randn()
        #newX = prevX + sigma * (beta * prevX) * np.random.randn()
        
        x.append(newX)
        
    plt.figure(2)
    plt.plot(x)
    plt.title('F0 = 1, beta = -0.5')
    
    
F0 = -1
beta = -0.5
np.random.seed(1)
for _ in range(nTraj):
    
    x = [F0]
    
    for i in range(nStep):
        
        prevX = x[-1]
        newX = prevX + sigma * (beta * prevX + (1 - beta) * F0) * np.random.randn()
        #newX = prevX + sigma * (beta * prevX) * np.random.randn()
        
        x.append(newX)
        
    plt.figure(3)
    plt.plot(x)
    plt.title('F0 = -1, beta = -0.5')

