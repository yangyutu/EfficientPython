# -*- coding: utf-8 -*-
"""
Created on Thu Apr 23 10:09:35 2020

@author: yangy
"""

import matplotlib.pyplot as plt
import numpy as np
F0 = 1

dt = 0.1
nTraj = 100
nStep = 100
sigma = 0.1
beta = 0.5
np.random.seed(1)
for _ in range(nTraj):
    
    x = [F0]
    
    for i in range(nStep):
        
        prevX = x[-1]
        newX = prevX + sigma * (prevX) ** beta * np.random.randn()
        x.append(newX)
        
    plt.figure(1)
    plt.plot(x)
    plt.title('beta = 0.5')


beta = -0.5
    
for _ in range(nTraj):
    
    x = [F0]
    
    for i in range(nStep):
        
        prevX = x[-1]
        newX = prevX + sigma * (prevX) ** beta * np.random.randn()
        x.append(newX)
        
    plt.figure(2)
    plt.plot(x)
    plt.title('beta = -0.5')
    
    


